import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from itertools import combinations, combinations_with_replacement


class RaceSimulator:
    """
    Simulates an F1 race strategy by calculating the time added
    from tire degradation and pit stops.
    """

    def __init__(self, race_laps: int = 60, pit_stop_time: float = 20):
        """
        Initialize the simulator and store tire data.

        Parameters:
            race_laps: Number of laps in the race (default 60).
            pit_stop_time: Seconds added by each pit stop (default 20).
        """
        self.race_laps = race_laps
        self.pit_stop_time = pit_stop_time

        # tire data from the Assignment 3a spreadsheet
        # key = tire name, value = dictionary with that tire's numbers
        self.tires = {}
        self.tires['Soft'] = {'Tmin': 0, 'Tmax': 10, 'alpha': 1 / 2, 'beta': 15}
        self.tires['Medium'] = {'Tmin': 1, 'Tmax': 10, 'alpha': 1 / 4, 'beta': 25}
        self.tires['Hard'] = {'Tmin': 2, 'Tmax': 10, 'alpha': 1 / 16, 'beta': 55}


    def tire_time(self, age, Tmin, Tmax, alpha, beta):
        """
        Calculate the time added due to tire degradation.

        Parameters:
            age: Tire age in laps (a number or a NumPy array of numbers).
            Tmin: Minimum time added by the tire.
            Tmax: Maximum time added by the tire.
            alpha: Tire degradation rate parameter.
            beta: Tire degradation midpoint parameter.

        Returns:
            Tire time added for the given tire age.
        """
        # S-shaped curve: starts near Tmin, goes up fastest around lap beta,
        # and levels off at Tmax. alpha controls how fast it goes up.
        # np.exp works on a whole array at once, so age can be an array
        # and we get one time for every lap (vectorized, no loop needed)
        time_added = Tmin + (Tmax - Tmin) / (1 + np.exp(-alpha * (age - beta)))
        return time_added


    def simulate(self, stint_lengths, tire_types):
        """
        Simulate a complete race strategy.

        Parameters:
            stint_lengths: Length of each race stint.
            tire_types: Tire compound used for each stint.

        Returns:
            Total time added from tire degradation and pit stops.
        """
        # check the inputs before doing any math
        if len(stint_lengths) != len(tire_types):
            raise ValueError("stint_lengths and tire_types must be the same length")

        total_laps = 0
        for length in stint_lengths:
            if length < 1:
                raise ValueError("every stint must be at least 1 lap long")
            total_laps += length

        if total_laps != self.race_laps:
            raise ValueError(f"the stints add up to {total_laps} laps, but the race is {self.race_laps} laps")

        for tire in tire_types:
            if tire not in self.tires:
                raise ValueError(f"{tire} is not a tire type. Use Soft, Medium or Hard")

        total_time = 0

        for i in range(len(stint_lengths)):
            tire = self.tires[tire_types[i]]

            # the tire age goes 1, 2, 3, ... for each lap of this stint
            ages = np.arange(1, stint_lengths[i] + 1)

            # time added on every lap of this stint (an array)
            lap_times = self.tire_time(ages, tire['Tmin'], tire['Tmax'], tire['alpha'], tire['beta'])

            total_time += np.sum(lap_times)

        # one pit stop between each stint
        number_of_stops = len(stint_lengths) - 1
        total_time += number_of_stops * self.pit_stop_time

        # float() turns the NumPy number into a normal Python number
        return float(total_time)


def plot_tires(simulator):
    """
    Plot tire degradation curves for all tire compounds.

    Parameters:
        simulator: A RaceSimulator object containing tire data.

    Returns:
        None.
    """
    ages = np.arange(1, simulator.race_laps + 1)

    for tire_name in simulator.tires:
        tire = simulator.tires[tire_name]
        times = simulator.tire_time(ages, tire['Tmin'], tire['Tmax'], tire['alpha'], tire['beta'])
        plt.plot(ages, times, label=tire_name)

    plt.title("Tire degradation")
    plt.xlabel("Tire age (laps)")
    plt.ylabel("Time added per lap (s)")
    plt.legend()
    plt.grid(True)
    plt.show()


def find_best_strategy(simulator, number_of_stops: int = 2):
    """
    Test all valid race strategies and find the one
    with the minimum total time added.

    A valid strategy has the given number of pit stops (default 2),
    every stint is at least 1 lap, and at least 2 different
    tire types are used (like the real F1 rule).

    Parameters:
        simulator: A RaceSimulator object.
        number_of_stops: How many pit stops the strategy has (default 2).

    Returns:
        The strategy with the lowest total tire and pit time,
        as a dictionary with the pit laps, stint lengths, tire types and total time.
    """
    tire_names = list(simulator.tires.keys())
    number_of_stints = number_of_stops + 1

    best_strategy = None
    strategies_tested = 0

    # every possible set of laps to pit on, for example (15, 23)
    # pitting on lap 15 means the new tire starts on lap 16
    for pit_laps in combinations(range(1, simulator.race_laps), number_of_stops):

        # turn the pit laps into stint lengths
        stint_lengths = []
        previous_lap = 0
        for lap in pit_laps:
            stint_lengths.append(lap - previous_lap)
            previous_lap = lap
        stint_lengths.append(simulator.race_laps - previous_lap)

        # every group of tires, for example ('Soft', 'Medium', 'Hard')
        # the order does not matter because every order of stint
        # lengths is already covered by the pit laps above
        for tire_types in combinations_with_replacement(tire_names, number_of_stints):

            # F1 rule: must use at least 2 different tire types
            if len(set(tire_types)) < 2:
                continue

            total_time = simulator.simulate(stint_lengths, tire_types)
            strategies_tested += 1

            if best_strategy is None or total_time < best_strategy['total_time']:
                best_strategy = {
                    'pit_laps': pit_laps,
                    'stint_lengths': stint_lengths,
                    'tire_types': tire_types,
                    'total_time': total_time,
                }

    best_strategy['strategies_tested'] = strategies_tested
    return best_strategy


if __name__ == "__main__":
    simulator = RaceSimulator()

    # same strategy as the Assignment 3a spreadsheet:
    # pit on laps 15 and 23, Soft -> Medium -> Hard
    example_time = simulator.simulate([15, 8, 37], ['Soft', 'Medium', 'Hard'])
    print("Spreadsheet strategy (pit laps 15 and 23, Soft/Medium/Hard):")
    print("Total time added:", round(example_time, 2), "s")
    print()

    plot_tires(simulator)

    best = find_best_strategy(simulator)
    print("Best strategy:")
    print("Pit stops on laps:", best['pit_laps'])
    print("Stint lengths:", best['stint_lengths'])
    print("Tire types:", best['tire_types'])
    print("Total time added:", round(best['total_time'], 2), "s")
    print("Strategies tested:", best['strategies_tested'])
