# DATA 2402 - Assignment 3: F1 Race Strategy

## Files

- **Assignment_3a.xlsx** - Part A: the race simulation in Excel
- **part_2.py** - Part B: the `RaceSimulator` class, `plot_tires` and `find_best_strategy`
- **Assignment3_demo.ipynb** - notebook that runs Part B with normal, special and error tests
- **tire_curves.png** - the tire degradation plot made by `plot_tires`

## How to run

```
pip install numpy pandas matplotlib
python part_2.py
```

Or open `Assignment3_demo.ipynb` in Jupyter and choose Run All.

## Assumptions

There were no written instructions, so these are the assumptions used in both parts:

- **Tire model:** time added on a lap = Tmin + (Tmax - Tmin) / (1 + e^(-alpha x (age - beta)))
- **Tire age:** 1 on the first lap of a stint, and goes up by 1 each lap
- **Race length:** 60 laps (same as the spreadsheet)
- **Pit stops:** each one adds 20 s. Pitting on lap 15 means the new tire starts on lap 16
- **Valid strategy:** 2 pit stops, every stint at least 1 lap, and at least 2 different tire types (the F1 rule)

## Results

- The spreadsheet strategy (pit on laps 15 and 23, Soft / Medium / Hard) adds **171.75 s**. Excel and Python give the same answer.
- The best strategy found pits on laps **14 and 37** using **Soft / Medium / Medium** and adds **134.92 s**.
