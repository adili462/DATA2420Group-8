DATA 2402 - Assignment 3 - F1 Tire Strategy

Files
- part_2.py - Part 2 code: RaceSimulator class, plot_tires and find_best_strategy
- Assignment3_demo.ipynb - notebook with the normal, special and error tests
- tire_curves.png - the tire plot made by plot_tires
- Assignment_3a.xlsx - Part 1 (already submitted separately)

How to run
- open Assignment3_demo.ipynb in Jupyter and run all the cells
- or run part_2.py
- finding the best strategy takes about 30 seconds

Rules used (from the assignment)
- the race is 60 laps with exactly 2 pit stops (3 stints)
- at least 2 different tire types must be used
- time added by a tire = Tmin + (Tmax - Tmin) / (1 + e^(-alpha x (age - beta)))
- a pit stop adds 25 s to the lap it is taken on
- on the pit stop lap the new tires are used and have an age of 0

Results
- spreadsheet strategy (pit on laps 15 and 23, Soft / Medium / Hard): 175.12 s in Excel and Python
- best strategy: pit on laps 16 and 39 with Soft / Medium / Medium: 134.27 s (11977 strategies tested)
