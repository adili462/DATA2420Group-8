import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from itertools import combinations, combinations_with_replacement


class RaceSimulator:
    """
    Simulates an F1 race strategy by calculating the time added
    from tire degradation and pit stops.
    """

    def __init__(self, race_laps: int = 60, pit_stop_time: float = 25):
        """
        Initialize the simulator and store tire data.

        Parameters:
            race_laps: Number of laps in the race (default 60).
            pit_stop_time: Seconds added to the lap a pit stop is taken (default 25).
        """
        self.race_laps = race_laps
        self.pit_stop_time = pit_stop_time

        # tire data from the assignment, stored in a pandas DataFrame
        # each row is one tire type, each column is one parameter
        self.tires = pd.DataFrame(
            {
                'Tmin': [0, 1, 2],
                'Tmax': [10, 10, 10],
                'alpha': [1 / 2, 1 / 4, 1 / 16],
                'beta': [15, 25, 55],
            },
            index=['Soft', 'Medium', 'Hard']
        )

        # the race DataFrame from the last call to simulate
        self.race = None


    def tire_time(self, age, Tmin, Tmax, alpha, beta):
        """
        Calculate the time added due to tire degradation.

        Parameters:
            age: Tire age in laps (a number, NumPy array or pandas column).
            Tmin: Minimum time added by the tire.
            Tmax: Maximum time added by the tire.
            alpha: Tire degradation rate parameter.
            beta: Tire degradation midpoint parameter.

        Returns:
            Tire time added for the given tire age.
        """
        # np.exp works on a whole array or column at once (vectorized),
        # so we get the time for every lap without a loop
        time_added = Tmin + (Tmax - Tmin) / (1 + np.exp(-alpha * (age - beta)))
        return time_added


    def clean_tire_name(self, tire) -> str:
        """
        Turns a tire name into the same format as the tire table,
        so ' soft ', 'SOFT' and 'Soft' all become 'Soft'.

        Parameters:
            tire: The tire name typed by the user.

        Returns:
            The tire name as it appears in the tire table.
        """
        if type(tire) != str:
            raise TypeError(f"tire type must be text, but got {tire}")

        # strip() removes spaces at the start and end,
        # capitalize() makes the first letter upper case and the rest lower case
        tire = tire.strip().capitalize()

        if tire not in self.tires.index:
            raise ValueError(f"{tire} is not a tire type. Use Soft, Medium or Hard")

        return tire


    def clean_whole_number(self, value) -> int:
        """
        Turns a lap count into an int, so 14 and 14.0 both become 14.

        Parameters:
            value: The number typed by the user.

        Returns:
            The number as an int.
        """
        try:
            number = float(value)
        except ValueError:
            raise TypeError(f"{value} is not a number")

        if number != int(number):
            raise ValueError(f"{value} is not a whole number of laps")

        return int(number)


    def simulate(self, stint_lengths, tire_types):
        """
        Simulate a complete race strategy.

        Parameters:
            stint_lengths: Length of each race stint, for example [14, 8, 38].
            tire_types: Tire compound used for each stint, for example ['Soft', 'Medium', 'Hard'].

        Returns:
            Total time added from tire degradation and pit stops.
        """
        # check the inputs
        if len(stint_lengths) != 3 or len(tire_types) != 3:
            raise ValueError("the race must have 2 pit stops, so 3 stint lengths and 3 tire types")

        lengths = []
        for length in stint_lengths:
            length = self.clean_whole_number(length)
            if length < 1:
                raise ValueError("every stint must be at least 1 lap long")
            lengths.append(length)

        if sum(lengths) != self.race_laps:
            raise ValueError(f"the stints add up to {sum(lengths)} laps, but the race is {self.race_laps} laps")

        tires = []
        for tire in tire_types:
            tires.append(self.clean_tire_name(tire))

        # a set has no repeats, so its length is the number of different tires
        if len(set(tires)) < 2:
            raise ValueError("at least 2 different tire types must be used")

        # make one DataFrame for each stint
        stints = []
        first_lap = 1
        for i in range(3):
            tire_data = self.tires.loc[tires[i]]

            # new tires have an age of 0 on the first lap of the stint
            ages = np.arange(0, lengths[i])

            # time added by the tire on every lap of this stint (vectorized)
            tire_times = self.tire_time(ages, tire_data['Tmin'], tire_data['Tmax'],
                                        tire_data['alpha'], tire_data['beta'])

            # the pit stop is on the first lap of stints 2 and 3
            pit_times = np.zeros(lengths[i])
            if i > 0:
                pit_times[0] = self.pit_stop_time

            stint = pd.DataFrame({
                'lap': np.arange(first_lap, first_lap + lengths[i]),
                'stint': i + 1,
                'tire': tires[i],
                'age': ages,
                'tire_time': tire_times,
                'pit_time': pit_times,
            })

            stints.append(stint)
            first_lap += lengths[i]

        # join the stints into one DataFrame for the whole race
        race = pd.concat(stints, ignore_index=True)
        race['lap_time_added'] = race['tire_time'] + race['pit_time']
        self.race = race

        # float() turns the NumPy number into a normal Python number
        return float(race['lap_time_added'].sum())


    def simulate_pit_laps(self, pit_laps, tire_types):
        """
        Simulate a race from the 2 pit stop lap numbers instead of the stint lengths.

        Parameters:
            pit_laps: The 2 laps the pit stops happen on, for example (15, 23).
            tire_types: Tire compound used for each stint.

        Returns:
            Total time added from tire degradation and pit stops.
        """
        if len(pit_laps) != 2:
            raise ValueError("there must be exactly 2 pit stop laps")

        first_stop = self.clean_whole_number(pit_laps[0])
        second_stop = self.clean_whole_number(pit_laps[1])

        # if the stops are typed in the wrong order, swap them
        if first_stop > second_stop:
            temp = first_stop
            first_stop = second_stop
            second_stop = temp

        if first_stop == second_stop:
            raise ValueError("the 2 pit stops can't be on the same lap")

        if first_stop < 2 or second_stop > self.race_laps:
            raise ValueError(f"pit stops must be between lap 2 and lap {self.race_laps}")

        # the new tires start on the pit stop lap
        stint_lengths = [first_stop - 1,
                         second_stop - first_stop,
                         self.race_laps - second_stop + 1]

        return self.simulate(stint_lengths, tire_types)


def plot_tires(simulator):
    """
    Plot tire degradation curves for all tire compounds.

    Parameters:
        simulator: A RaceSimulator object containing tire data.

    Returns:
        None.
    """
    ages = np.arange(0, simulator.race_laps + 1)

    for tire_name in simulator.tires.index:
        tire = simulator.tires.loc[tire_name]
        times = simulator.tire_time(ages, tire['Tmin'], tire['Tmax'], tire['alpha'], tire['beta'])
        plt.plot(ages, times, label=tire_name)

    plt.title("Tire degradation")
    plt.xlabel("Tire age (laps)")
    plt.ylabel("Time added per lap (s)")
    plt.legend()
    plt.grid(True)
    plt.show()


def find_best_strategy(simulator):
    """
    Test all valid race strategies and find the one
    with the minimum total time added.

    A valid strategy has 2 pit stops on different laps (lap 2 to lap 60),
    and uses at least 2 different tire types.

    Parameters:
        simulator: A RaceSimulator object.

    Returns:
        The strategy with the lowest total tire and pit time,
        as a dictionary with the pit laps, stint lengths, tire types and total time.
    """
    tire_names = list(simulator.tires.index)

    best_strategy = None
    strategies_tested = 0

    # every possible pair of pit stop laps, for example (15, 23)
    # combinations never repeats a lap and always puts them in order
    for pit_laps in combinations(range(2, simulator.race_laps + 1), 2):

        # every group of 3 tires, for example ('Soft', 'Medium', 'Medium')
        # the order does not matter because every order of stint
        # lengths is already covered by the pit laps above
        for tire_types in combinations_with_replacement(tire_names, 3):

            # must use at least 2 different tire types
            if len(set(tire_types)) < 2:
                continue

            total_time = simulator.simulate_pit_laps(pit_laps, tire_types)
            strategies_tested += 1

            if best_strategy is None or total_time < best_strategy['total_time']:
                best_strategy = {
                    'pit_laps': pit_laps,
                    'tire_types': tire_types,
                    'total_time': total_time,
                }

    best_strategy['strategies_tested'] = strategies_tested
    return best_strategy


if __name__ == "__main__":
    simulator = RaceSimulator()

    # same strategy as the Part 1 spreadsheet:
    # pit on laps 15 and 23, Soft -> Medium -> Hard
    example_time = simulator.simulate_pit_laps((15, 23), ['Soft', 'Medium', 'Hard'])
    print("Spreadsheet strategy (pit laps 15 and 23, Soft/Medium/Hard):")
    print("Total time added:", round(example_time, 2), "s")
    print()

    plot_tires(simulator)

    best = find_best_strategy(simulator)
    print("Best strategy:")
    print("Pit stops on laps:", best['pit_laps'])
    print("Tire types:", best['tire_types'])
    print("Total time added:", round(best['total_time'], 2), "s")
    print("Strategies tested:", best['strategies_tested'])
