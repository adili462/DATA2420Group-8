import pandas as pd


def task1_load_explore():
    """
    Task 1: load both csv files and look at what is in them.
    :return: main_df and prices_df
    """
    # low_memory=False stops the mixed types warning (the bust column has numbers and some text like '37-39')
    main_df = pd.read_csv('modcloth_main.csv', low_memory=False)
    prices_df = pd.read_csv('modcloth_prices.csv')

    print("----- MAIN DATASET -----")
    print("First five rows:")
    print(main_df.head())
    print()
    print("Dimensions (rows, columns):", main_df.shape)
    print()
    print("Column names:")
    print(main_df.columns)
    print()
    print("Data types and non-null values:")
    main_df.info()
    print()
    print("Missing values in each column:")
    print(main_df.isna().sum())
    print()

    print("----- PRICES DATASET -----")
    print("First five rows:")
    print(prices_df.head())
    print()
    print("Dimensions (rows, columns):", prices_df.shape)
    print()
    print("Column names:")
    print(prices_df.columns)
    print()
    print("Data types and non-null values:")
    prices_df.info()
    print()
    print("Missing values in each column:")
    print(prices_df.isna().sum())
    print()

    # find the columns that are in both datasets
    common_columns = []
    for name in main_df.columns:
        if name in prices_df.columns:
            common_columns.append(name)
    print("Columns in both datasets:", common_columns)
    print()

    return main_df, prices_df


def task2_merge_data(main_df, prices_df):
    """
    Task 2: merge the two DataFrames in four different ways.
    :param main_df: the main DataFrame from task 1
    :param prices_df: the prices DataFrame from task 1
    :return: inner_merged, left_merged, right_merged, outer_merged
    """
    # check that the key is really in both before merging
    if 'item_id' in main_df.columns and 'item_id' in prices_df.columns:
        print("item_id is in both datasets, so it is used as the key")
    else:
        print("item_id is NOT in both datasets")
    print()

    # A. inner: only items that are in both
    inner_merged = pd.merge(main_df, prices_df, on='item_id', how='inner')
    print("----- A. INNER MERGE -----")
    print(inner_merged.head())
    print("Dimensions:", inner_merged.shape)
    print()

    # B. left: every row from main, price is NaN if there is no match
    left_merged = pd.merge(main_df, prices_df, on='item_id', how='left')
    print("----- B. LEFT MERGE -----")
    print(left_merged.head())
    print("Dimensions:", left_merged.shape)
    print()

    # C. right: every row from prices, main columns are NaN if there is no match
    right_merged = pd.merge(main_df, prices_df, on='item_id', how='right')
    print("----- C. RIGHT MERGE -----")
    print(right_merged.head())
    print("Dimensions:", right_merged.shape)
    print()

    # D. outer: every row from both
    outer_merged = pd.merge(main_df, prices_df, on='item_id', how='outer')
    print("----- D. OUTER MERGE -----")
    print(outer_merged.head())
    print("Dimensions:", outer_merged.shape)
    print()

    return inner_merged, left_merged, right_merged, outer_merged


def task3_analyze_merges(merge_results):
    """
    Task 3: compare the four merged DataFrames.
    :param merge_results: the four DataFrames from task 2 (inner, left, right, outer)
    :return: the four DataFrames and a dictionary with the analysis results
    """
    inner_merged = merge_results[0]
    left_merged = merge_results[1]
    right_merged = merge_results[2]
    outer_merged = merge_results[3]

    # 1. compare the dimensions
    print("----- DIMENSIONS -----")
    print("Inner:", inner_merged.shape)
    print("Left: ", left_merged.shape)
    print("Right:", right_merged.shape)
    print("Outer:", outer_merged.shape)
    print()

    # 2. missing values in each result
    print("----- MISSING VALUES -----")
    print("Inner:")
    print(inner_merged.isna().sum())
    print()
    print("Left:")
    print(left_merged.isna().sum())
    print()
    print("Right:")
    print(right_merged.isna().sum())
    print()
    print("Outer:")
    print(outer_merged.isna().sum())
    print()

    # 3. which records are in both, only main, or only prices
    # in both: every row of the inner merge
    in_both = inner_merged
    # only in main: the price is missing (no match in prices)
    only_main = outer_merged[outer_merged['price'].isna()]
    # only in prices: user_id is missing (no review in main)
    only_prices = outer_merged[outer_merged['user_id'].isna()]

    print("----- MATCHED AND UNMATCHED -----")
    print("Rows in both datasets:", len(in_both))
    print("Different items in both datasets:", len(in_both['item_id'].unique()))
    print("Rows only in main (no price):", len(only_main))
    print("Rows only in prices (no reviews):", len(only_prices))
    print()
    print("Items only in prices:")
    print(only_prices[['item_id', 'price']])
    print()

    # 4. how each merge handled the unmatched rows
    print("----- UNMATCHED ROWS IN EACH MERGE -----")
    print("Inner: missing prices =", inner_merged['price'].isna().sum(),
          " missing user_id =", inner_merged['user_id'].isna().sum())
    print("Left:  missing prices =", left_merged['price'].isna().sum(),
          " missing user_id =", left_merged['user_id'].isna().sum())
    print("Right: missing prices =", right_merged['price'].isna().sum(),
          " missing user_id =", right_merged['user_id'].isna().sum())
    print("Outer: missing prices =", outer_merged['price'].isna().sum(),
          " missing user_id =", outer_merged['user_id'].isna().sum())
    print()

    # 5. summary
    print("----- SUMMARY -----")
    print("Inner keeps only the", len(inner_merged), "rows that match")
    print("Left keeps all", len(left_merged), "rows from main")
    print("Right keeps all rows from prices, so it has", len(right_merged), "rows")
    print("Outer keeps everything from both, so it has", len(outer_merged), "rows")
    print()

    results = {}
    results['inner_rows'] = len(inner_merged)
    results['left_rows'] = len(left_merged)
    results['right_rows'] = len(right_merged)
    results['outer_rows'] = len(outer_merged)
    results['in_both'] = len(in_both)
    results['only_main'] = len(only_main)
    results['only_prices'] = len(only_prices)

    return inner_merged, left_merged, right_merged, outer_merged, results


def main():
    main_df, prices_df = task1_load_explore()
    merge_results = task2_merge_data(main_df, prices_df)
    task3_analyze_merges(merge_results)


if __name__ == "__main__":
    main()
